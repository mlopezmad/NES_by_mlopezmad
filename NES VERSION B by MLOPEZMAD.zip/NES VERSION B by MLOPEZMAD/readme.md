# NES by mlopezmad


## Important!

In this theme you can't use the recent and expert tabs, otherwise you will see that the screens are displaced. 
Make sure you have them disabled in: **Apps** -> **Tweaks** -> **Appearance**.


## Credits

- Screen backgrounds by mlopezmad

- Icons RetroArch Type I By Vidnez

- Images menu and select game by mlopezmad

- All other icons derived from stock Miyoo Mini icons

## Thanks

Thanks to the entire Onion team, especially aemiii, always helping with the doubts I have had on the subject.
